# Curso: Arquitecturas Distribuidas con Python y FastAPI

Material completo para un taller práctico de cuatro horas. Incluye una introducción breve a Python y ocho ejercicios con FastAPI, WebSocket, HTML, CSS y JavaScript sin frameworks de frontend. El sitio está construido con VuePress.

## Ejecutar el sitio

```bash
npm install
npm run docs:dev
```

## Construir el sitio

```bash
npm run docs:build
```

## Ejecutar cualquier proyecto

```bash
cd codigo/01-websocket-base
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app:app --reload
```
