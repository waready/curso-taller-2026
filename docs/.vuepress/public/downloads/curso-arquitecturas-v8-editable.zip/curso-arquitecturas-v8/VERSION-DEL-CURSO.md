# Versión 8 — fuente completa y editable

Este paquete corresponde a la versión publicada el 5 de septiembre de 2026.

## Contenido incluido

- Sitio VuePress completo con el diseño institucional del CIP Puno.
- Módulo de instalación de Python, VS Code, Codex y Claude Code.
- Módulo **Python esencial** con sintaxis, variables, tipos de datos, colecciones, condicionales, ciclos, funciones, clases, decoradores y `async`/`await`.
- Módulo **WebSocket esencial** con HTTP vs. WebSocket, eventos JSON, conexión, broadcast, desconexión y errores frecuentes.
- Tablas corregidas para escritorio y dispositivos móviles.
- Ocho proyectos completos de Python y FastAPI dentro de `codigo/`.
- Código visible y copiable desde las páginas generadas en `docs/codigo/`.
- Logo institucional en `docs/.vuepress/public/cip-logo.png`.

## Archivos principales para editar

- `docs/python-esencial.md`
- `docs/laboratorio-websocket.md`
- `docs/preparacion.md`
- `docs/plan.md`
- `docs/.vuepress/styles/index.scss`
- `docs/.vuepress/config.js`
- `codigo/`

Consulta `EDITAR-EL-CURSO.md` para abrir y modificar el sitio en tu computadora.
