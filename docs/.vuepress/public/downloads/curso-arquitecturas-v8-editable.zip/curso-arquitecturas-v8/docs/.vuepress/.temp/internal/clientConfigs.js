import * as clientConfig0 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-active-header-links/dist/client/config.js'
import * as clientConfig1 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-back-to-top/dist/client/config.js'
import * as clientConfig2 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-copy-code/dist/client/config.js'
import * as clientConfig3 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-markdown-hint/dist/client/config.js'
import * as clientConfig4 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/.temp/git/config.js'
import * as clientConfig5 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-medium-zoom/dist/client/config.js'
import * as clientConfig6 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-nprogress/dist/client/config.js'
import * as clientConfig7 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/.temp/prismjs/config.js'
import * as clientConfig8 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/.temp/markdown-tab/config.js'
import * as clientConfig9 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-theme-data/dist/client/config.js'
import * as clientConfig10 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/theme-default/dist/client/config.js'
import * as clientConfig11 from 'C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/client.js'

export const clientConfigs = [
  clientConfig0,
  clientConfig1,
  clientConfig2,
  clientConfig3,
  clientConfig4,
  clientConfig5,
  clientConfig6,
  clientConfig7,
  clientConfig8,
  clientConfig9,
  clientConfig10,
  clientConfig11,
].map((m) => m.default).filter(Boolean)
