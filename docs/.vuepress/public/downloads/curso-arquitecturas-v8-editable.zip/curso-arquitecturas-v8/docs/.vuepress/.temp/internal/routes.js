export const redirects = JSON.parse("{}")

export const routes = Object.fromEntries([
  ["/ia.html", { loader: () => import(/* webpackChunkName: "ia.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/ia.md"), meta: {"title":"Desarrollo asistido por IA"} }],
  ["/laboratorio-websocket.html", { loader: () => import(/* webpackChunkName: "laboratorio-websocket.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/laboratorio-websocket.md"), meta: {"title":"WebSocket esencial y laboratorio"} }],
  ["/plan.html", { loader: () => import(/* webpackChunkName: "plan.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/plan.md"), meta: {"title":"Ruta práctica de 4 horas"} }],
  ["/preparacion.html", { loader: () => import(/* webpackChunkName: "preparacion.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/preparacion.md"), meta: {"title":"Instaladores y preparación"} }],
  ["/python-esencial.html", { loader: () => import(/* webpackChunkName: "python-esencial.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/python-esencial.md"), meta: {"title":"Python esencial para el taller"} }],
  ["/", { loader: () => import(/* webpackChunkName: "index.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/README.md"), meta: {"title":""} }],
  ["/codigo/01-websocket-base.html", { loader: () => import(/* webpackChunkName: "codigo_01-websocket-base.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/01-websocket-base.md"), meta: {"title":"WebSocket Base — código completo"} }],
  ["/codigo/02-chat-tiempo-real.html", { loader: () => import(/* webpackChunkName: "codigo_02-chat-tiempo-real.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/02-chat-tiempo-real.md"), meta: {"title":"Chat con presencia — código completo"} }],
  ["/codigo/03-wplace-colaborativo.html", { loader: () => import(/* webpackChunkName: "codigo_03-wplace-colaborativo.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/03-wplace-colaborativo.md"), meta: {"title":"Mini-WPlace colaborativo — código completo"} }],
  ["/codigo/04-reacciones-en-vivo.html", { loader: () => import(/* webpackChunkName: "codigo_04-reacciones-en-vivo.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/04-reacciones-en-vivo.md"), meta: {"title":"Reacciones en vivo — código completo"} }],
  ["/codigo/05-encuesta-battle.html", { loader: () => import(/* webpackChunkName: "codigo_05-encuesta-battle.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/05-encuesta-battle.md"), meta: {"title":"Encuesta Battle — código completo"} }],
  ["/codigo/06-cursor-party.html", { loader: () => import(/* webpackChunkName: "codigo_06-cursor-party.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/06-cursor-party.md"), meta: {"title":"Cursor Party — código completo"} }],
  ["/codigo/07-tracker-delivery.html", { loader: () => import(/* webpackChunkName: "codigo_07-tracker-delivery.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/07-tracker-delivery.md"), meta: {"title":"Tracker tipo Uber — código completo"} }],
  ["/codigo/08-subasta-flash.html", { loader: () => import(/* webpackChunkName: "codigo_08-subasta-flash.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/08-subasta-flash.md"), meta: {"title":"Subasta Flash — código completo"} }],
  ["/codigo/09-cartas-casino.html", { loader: () => import(/* webpackChunkName: "codigo_09-cartas-casino.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/09-cartas-casino.md"), meta: {"title":"Cartas Casino — código completo"} }],
  ["/codigo/10-openai-lab.html", { loader: () => import(/* webpackChunkName: "codigo_10-openai-lab.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/10-openai-lab.md"), meta: {"title":"OpenAI Lab con FastAPI — código completo"} }],
  ["/codigo/", { loader: () => import(/* webpackChunkName: "codigo_index.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/codigo/README.md"), meta: {"title":"Código completo de la clase"} }],
  ["/proyectos/cartas.html", { loader: () => import(/* webpackChunkName: "proyectos_cartas.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/cartas.md"), meta: {"title":"Cartas Casino"} }],
  ["/proyectos/chat.html", { loader: () => import(/* webpackChunkName: "proyectos_chat.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/chat.md"), meta: {"title":"Proyecto A: Chat con presencia"} }],
  ["/proyectos/cursor-party.html", { loader: () => import(/* webpackChunkName: "proyectos_cursor-party.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/cursor-party.md"), meta: {"title":"Cursor Party"} }],
  ["/proyectos/encuesta.html", { loader: () => import(/* webpackChunkName: "proyectos_encuesta.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/encuesta.md"), meta: {"title":"Encuesta Battle"} }],
  ["/proyectos/openai-lab.html", { loader: () => import(/* webpackChunkName: "proyectos_openai-lab.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/openai-lab.md"), meta: {"title":"OpenAI Lab con FastAPI"} }],
  ["/proyectos/reacciones.html", { loader: () => import(/* webpackChunkName: "proyectos_reacciones.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/reacciones.md"), meta: {"title":"Proyecto C: Reacciones en vivo"} }],
  ["/proyectos/", { loader: () => import(/* webpackChunkName: "proyectos_index.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/README.md"), meta: {"title":"Demos completas"} }],
  ["/proyectos/subasta.html", { loader: () => import(/* webpackChunkName: "proyectos_subasta.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/subasta.md"), meta: {"title":"Subasta Flash"} }],
  ["/proyectos/tracker.html", { loader: () => import(/* webpackChunkName: "proyectos_tracker.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/tracker.md"), meta: {"title":"Tracker tipo Uber"} }],
  ["/proyectos/websocket-base.html", { loader: () => import(/* webpackChunkName: "proyectos_websocket-base.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/websocket-base.md"), meta: {"title":"WebSocket Base"} }],
  ["/proyectos/wplace.html", { loader: () => import(/* webpackChunkName: "proyectos_wplace.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/proyectos/wplace.md"), meta: {"title":"Proyecto B: WPlace colaborativo"} }],
  ["/404.html", { loader: () => import(/* webpackChunkName: "404.html" */"C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/.temp/pages/404.html.vue"), meta: {"title":""} }],
]);

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  __VUE_HMR_RUNTIME__.updateRoutes?.(routes)
  __VUE_HMR_RUNTIME__.updateRedirects?.(redirects)
}

if (import.meta.hot) {
  import.meta.hot.accept((m) => {
    __VUE_HMR_RUNTIME__.updateRoutes?.(m.routes)
    __VUE_HMR_RUNTIME__.updateRedirects?.(m.redirects)
  })
}
