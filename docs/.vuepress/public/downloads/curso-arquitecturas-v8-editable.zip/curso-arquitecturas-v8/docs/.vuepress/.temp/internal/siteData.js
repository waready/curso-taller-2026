export const siteData = JSON.parse("{\"base\":\"/\",\"lang\":\"es-PE\",\"title\":\"CIP Puno · Formación\",\"description\":\"Arquitecturas Distribuidas y Desarrollo Asistido por Inteligencia Artificial con Python y FastAPI\",\"head\":[[\"meta\",{\"name\":\"theme-color\",\"content\":\"#071a2b\"}],[\"meta\",{\"name\":\"color-scheme\",\"content\":\"dark light\"}],[\"link\",{\"rel\":\"icon\",\"type\":\"image/png\",\"href\":\"/cip-logo.png\"}]],\"locales\":{\"/\":{\"lang\":\"es-PE\",\"title\":\"CIP Puno · Formación\",\"description\":\"Arquitecturas Distribuidas y Desarrollo Asistido por Inteligencia Artificial con Python y FastAPI\"}}}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  __VUE_HMR_RUNTIME__.updateSiteData?.(siteData)
}

if (import.meta.hot) {
  import.meta.hot.accept((m) => {
    __VUE_HMR_RUNTIME__.updateSiteData?.(m.siteData)
  })
}
