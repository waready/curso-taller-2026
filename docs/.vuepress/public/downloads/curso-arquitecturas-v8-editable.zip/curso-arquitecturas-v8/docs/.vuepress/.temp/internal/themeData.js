export const themeData = JSON.parse("{\"logo\":\"/cip-logo.png\",\"logoAlt\":\"Colegio de Ingenieros del Perú\",\"navbar\":[{\"text\":\"Inicio\",\"link\":\"/\"},{\"text\":\"Instaladores\",\"link\":\"/preparacion.html\"},{\"text\":\"Python esencial\",\"link\":\"/python-esencial.html\"},{\"text\":\"WebSocket esencial\",\"link\":\"/laboratorio-websocket.html\"},{\"text\":\"Prompts de IA\",\"link\":\"/ia.html\"},{\"text\":\"Demos y ejercicios\",\"link\":\"/proyectos/\"},{\"text\":\"Código\",\"link\":\"/codigo/\"}],\"sidebar\":{\"/proyectos/\":[{\"text\":\"Proyectos por grupos\",\"children\":[\"/proyectos/README.md\",\"/proyectos/websocket-base.md\",\"/proyectos/chat.md\",\"/proyectos/wplace.md\",\"/proyectos/reacciones.md\",\"/proyectos/encuesta.md\",\"/proyectos/cursor-party.md\",\"/proyectos/tracker.md\",\"/proyectos/subasta.md\",\"/proyectos/cartas.md\",\"/proyectos/openai-lab.md\"]}],\"/codigo/\":[{\"text\":\"Código completo\",\"children\":[\"/codigo/README.md\",\"/codigo/01-websocket-base.md\",\"/codigo/02-chat-tiempo-real.md\",\"/codigo/03-wplace-colaborativo.md\",\"/codigo/04-reacciones-en-vivo.md\",\"/codigo/05-encuesta-battle.md\",\"/codigo/06-cursor-party.md\",\"/codigo/07-tracker-delivery.md\",\"/codigo/08-subasta-flash.md\",\"/codigo/09-cartas-casino.md\",\"/codigo/10-openai-lab.md\"]}],\"/\":[{\"text\":\"Taller de 4 horas\",\"children\":[\"/preparacion.md\",\"/python-esencial.md\",\"/laboratorio-websocket.md\",\"/ia.md\"]}]},\"editLink\":false,\"contributors\":false,\"lastUpdated\":false,\"notFound\":[\"Esta ruta se desconectó.\",\"Aquí no vive ningún WebSocket.\"],\"backToHome\":\"Volver al inicio\",\"toggleColorMode\":\"Cambiar tema\",\"toggleSidebar\":\"Abrir menú\",\"locales\":{\"/\":{\"selectLanguageName\":\"English\"}},\"colorMode\":\"auto\",\"colorModeSwitch\":true,\"repo\":null,\"selectLanguageText\":\"Languages\",\"selectLanguageAriaLabel\":\"Select language\",\"sidebarDepth\":2,\"editLinkText\":\"Edit this page\",\"contributorsText\":\"Contributors\",\"openInNewWindow\":\"open in new window\"}")

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updateThemeData) {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ themeData }) => {
    __VUE_HMR_RUNTIME__.updateThemeData(themeData)
  })
}
