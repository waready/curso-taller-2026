import "C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/docs/.vuepress/styles/index.scss"
