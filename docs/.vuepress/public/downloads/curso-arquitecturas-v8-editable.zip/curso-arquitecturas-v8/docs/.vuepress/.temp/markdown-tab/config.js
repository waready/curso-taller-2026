import { CodeTabs } from "C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-markdown-tab/dist/client/components/CodeTabs.js";
import { Tabs } from "C:/Users/Descktop-11/Downloads/curso-arquitecturas-v8-editable/curso-arquitecturas-v8/node_modules/@vuepress/plugin-markdown-tab/dist/client/components/Tabs.js";

export default {
  enhance: ({ app }) => {
    app.component("CodeTabs", CodeTabs);
    app.component("Tabs", Tabs);
  },
};
