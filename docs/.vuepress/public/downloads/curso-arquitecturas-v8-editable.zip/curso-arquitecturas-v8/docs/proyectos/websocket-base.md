# WebSocket Base

[Abrir demo en Vercel](https://cip-puno-01-websocket-base.vercel.app) · [Ver codigo completo](/codigo/01-websocket-base.html)

La practica inicial para conectar varias pestañas, enviar mensajes y observar
cuantas conexiones siguen activas.
